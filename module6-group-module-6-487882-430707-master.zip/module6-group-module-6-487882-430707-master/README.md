# CSE330
Chan Lee 487882 chanlee20
Danny Kim 430707 attractson

http://ec2-3-133-120-6.us-east-2.compute.amazonaws.com:3456/

Creative Portions
1) Chat bot
- /room > explanation of the room
- /intro > basic instruction of the chat service 
- /user > show all user in the current room

2) Word Censoring
- Cannot use certain words (Bitch, Fuck) : just type these words


-1 Pts: did not upload gitignore file 
49/50
